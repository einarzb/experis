$(document).ready( function() {

//initalize - change array to object!!
        var cart = [];
        var bill = 0;
//******************************************** populating products to shop ***************************************************
        var container = $("#container");
           for (var i = 0; i < products.length; ++i) {
                 products[i].qty = 0;

                 var productName = '<h5>' + products[i].name + '</h5>';
                 var productPrice = '<p>' + '$' + products[i].price + '</p>' ;
                 var productImage = '<img src=' + products[i].image + '>';
                 var addToCartBtn = '<button class="add-to-cart openCart"> cart</button>';
                 var datas = 'data-price=' + products[i].price + ' ' + 'data-name=' + products[i].name + ' ' + 'data-qty=' + products[i].qty + ' ';

                 //appending to html
                 $('<li ' + datas + '>').html(productName + productPrice + productImage + addToCartBtn).appendTo('#container');
            }

//******************************************** MAIN - add products to cart ***************************************************
        $('.add-to-cart').on('click', function () {
               //selected product by index!
               var selectedName = $(this).parent().data().name;
               var selectedPrice = $(this).parent().data().price;
               var counter = 1;
              //var selectedProduct = $(this).parent().index();

              //create object
               var item = {selectedName:selectedName, selectedPrice:selectedPrice, counter:counter};
               //invoke other functions
               addItem(item);
               fillCart(item);
         });

//******************************************** add products to cart ***************************************************

        function addItem(item){
          //flag for checking if ites exists IN CART
            var itemExists = false;
          //if product exist
            for (var i = 0; i < cart.length; i++) {
              if(cart[i] === item.selectedName){
                cart[i].counter++;
                itemExists = true;
              }
            };
            //if ITS not exist
            if (!itemExists) {
              cart.push(item);
            }
        };

//******************************************** PRINT CART ***************************************************
      function fillCart(item){
            //INITIAL
            var qty = 0;
            var tr= $('<tr>');

            var removeBtn = "<td><a class='removeQuantity' href='#'>-</a></td>";
            var productName = "<td> " + item.selectedName + "</td>";
            var productPrice = "<td>" + item.selectedPrice + "</td>";
            var productQty = "<td><input type=number" + " " + 'min="1"' + "value=" + item.counter + " "  + "class=qtyInput></input></td>";

          //*******************LISTEN TO changes for qty input spinner***************
              $("body").on('change', "input", function(){
                  productQty = $(".qtyInput").val();
                  console.log(productQty);
                  console.log(item.selectedPrice);
                  bill = (productQty * item.selectedPrice).toFixed();
                  console.log(bill);
              });
        //calc bill
              bill = (item.counter * item.selectedPrice).toFixed();
              var productBill = "<td>" + bill + "</td>";

        //ux - append everything to table
               tr.append(productName);
               tr.append(productPrice);
               tr.append(productQty);
               tr.append(productBill);
               tr.append(removeBtn);

               //append all to the table
               $(".cartTable").append(tr);
               $("#bill").append(bill);
           };

//******************************************** remove product from cart ***************************************************
         $("body").on('click', ".removeQuantity", function () {
           //the tr that holds the X btn(td)
           var selectToDelete = $(this).parent().parent();
           selectToDelete.remove();
         });

//******************************************** open cart ***************************************************
          $("body").on('click', ".openCart", function () {
            $('#cart').css('display','block');
           });


//end of document ready function
});
