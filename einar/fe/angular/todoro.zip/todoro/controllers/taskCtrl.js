var app = angular.module('todoApp', []);

app.controller('taskCtrl', ['tasksService', function(tasksService){
  // this.tasks = tasksService.saveTasks;
  this.tasks = [];
  this.addTask = tasksService.addTaskToTasks();





}]);
