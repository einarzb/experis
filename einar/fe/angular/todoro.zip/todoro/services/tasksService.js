
app.service('tasksService', function(){

  this.addTaskToTasks = function(){
  return  function(newTask){
      this.tasks.push(newTask);
      console.log(this.tasks);
    }
  }

  // this.saveTasks = function(){
  //   this.tasks;
  // }

});
