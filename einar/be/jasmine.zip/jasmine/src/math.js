
//function to be tested would be places in src folder
// function addNums(a,b){
//   return a + b;
// }

//would fail the second test
function addNums(a,b){
  a = Math.abs(a);
  b = Math.abs(b);
  return;
}

module.exports.addNums = addNums;
